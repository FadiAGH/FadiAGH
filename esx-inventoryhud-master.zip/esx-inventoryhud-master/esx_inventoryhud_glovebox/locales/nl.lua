Locales["nl"] = {
  ["glovebox_closed"] = "Het handschoenenkastje is gesloten.",
  ["no_veh_nearby"] = "Er is geen voertuig in de buurt.",
  ["glovebox_in_use"] = "Iemand anders gebruikt dit handschoenenkastje.",
  ["glovebox_full"] = "Dit handschoenenkastje is vol.",
  ["invalid_quantity"] = "Ongeldig aantal",
  ["cant_carry_more"] = "Je kunt niet meer bij je dragen.",
  ["nacho_veh"] = "Dit is niet jouw voertuig.",
  ["invalid_amount"] = "Ongeldig aantal",
  ["insufficient_space"] = "Onvoldoende ruimte",
  ["glovebox_info"] = "<h3>Handschoenenkastje</h3><br><strong>Kenteken:</strong> %s<br><strong>Capaciteit:</strong> %s / %s",
  ["player_inv_no_space"] = "Je hebt onvoldoende ruimte in je inventaris voor dit item!"
}
